#include <iostream>
#include <string>
#include "book.h"

using namespace std;

Book::Book()
{
    next = NULL;
    prev = NULL;
}

Book::Book (string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek)
{
    this->imieAktora = imieAktora;
    this->nazwiskoAktora = nazwiskoAktora;
    this->imiePostaci = imiePostaci;
    this->nazwiskoPostaci = nazwiskoPostaci;
    this->pierwszyOdcinek = pierwszyOdcinek;
    this->ostatniOdcinek = ostatniOdcinek;

    next = NULL;
    prev = NULL;
}

void Book::dodaj(string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek)
{
    Book *nowy = new Book (imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci, pierwszyOdcinek, ostatniOdcinek);
    Book *ostatni = this;
    while (ostatni->next != NULL)
    {
        ostatni = ostatni-> next;
    }
    ostatni -> next = nowy;
    (ostatni -> next) -> prev = ostatni;
}

void Book::drukuj()
{
    Book *ostatni = this;
    ostatni = ostatni->next;
    while (ostatni->next != NULL)
    {
        cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
        ostatni = ostatni -> next;
    }
    cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
}

void Book::drukuj(int i)
{
    int licznik = 0;
    Book *ostatni = this;
    while ((licznik < i)&&(ostatni->next != NULL))
    {
        ostatni = ostatni -> next;
        licznik++;
    }
    cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
}

