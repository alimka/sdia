#include<iostream>
#include<string>
#include "book.h"

using namespace std;

int main()
{
    book lista;
    lista.dodaj("Agnieszka","Cieślińska", "Catalina", "García", 12345, 9876 );
    lista.dodaj("Sławek" ,"Borzdyński" ,"Dario" ,"Fernández", 70, 987);

    lista.drukuj();
    lista.drukuj(1);
    lista[1];

    int liczbaPolecen, polecenie, index;

    cin >> liczbaPolecen;
    while (liczbaPolecen--)
    {
        cin >> polecenie;
        switch(polecenie)
        {
            case 1:
                {
                    string imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci;
                    int pierwszyOdcinek, ostatniOdcinek;
                    cin >> imieAktora >> nazwiskoAktora >> imiePostaci >> nazwiskoPostaci >> pierwszyOdcinek >> ostatniOdcinek;
                    lista.dodaj(imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci, pierwszyOdcinek, ostatniOdcinek);
                    break;
                }
            case 2:
                {
                    //sortujAktorow();
                    break;
                }
            case 3:
                {
                    //sortujPostaci();
                    break;
                }
            case 4:
                {
                    cin >> index;
                    cout << "Index: " << index << endl;
                    lista.drukuj(index);
                    break;
                }
        }
    }
    lista.drukuj();
    lista.drukuj(1);
    lista[1];
    return 0;
}
