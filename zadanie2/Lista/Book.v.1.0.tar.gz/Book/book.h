#ifndef BOOK_H
#define BOOK_H

#include <string>

using namespace std;

class book
{
public:
    string imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci;
    int pierwszyOdcinek, ostatniOdcinek;

    book* next;
    book* prev;

    book();
    book (string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek);

    book* operator[](int q);
    ostream& operator<<(ostream& os, book& a);


    void dodaj(string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek);
    void drukuj();
    void drukuj(int i);
    void sortujAktorow();
    void sortujPostaci();
};

#endif // BOOK_H
