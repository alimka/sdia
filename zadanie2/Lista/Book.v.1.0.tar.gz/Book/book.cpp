#include <iostream>
#include <string>
#include "book.h"

using namespace std;

book::book()
{
    next = NULL;
    prev = NULL;
}

book::book (string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek)
{
    this->imieAktora = imieAktora;
    this->nazwiskoAktora = nazwiskoAktora;
    this->imiePostaci = imiePostaci;
    this->nazwiskoPostaci = nazwiskoPostaci;
    this->pierwszyOdcinek = pierwszyOdcinek;
    this->ostatniOdcinek = ostatniOdcinek;

    next = NULL;
    prev = NULL;
}

void book::dodaj(string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek)
{
    book *nowy = new book (imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci, pierwszyOdcinek, ostatniOdcinek);
    book *ostatni = this;
    while (ostatni->next != NULL)
    {
        ostatni = ostatni-> next;
    }
    ostatni -> next = nowy;
    (ostatni -> next) -> prev = ostatni;
}

void book::drukuj()
{
    book *ostatni = this;
    ostatni = ostatni->next;
    while (ostatni->next != NULL)
    {
        cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
        ostatni = ostatni -> next;
    }
    cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
}

void book::drukuj(int i)
{
    int licznik = 0;
    book *ostatni = this;
    while ((licznik < i)&&(ostatni->next != NULL))
    {
        ostatni = ostatni -> next;
        licznik++;
    }
    cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
}

void book::sortujAktorow() //QuickSort
{
}

void book::sortujPostaci() //Mergesort
{
}

book* book::operator [](int q)
{
    int licznik = 0;
    book *ostatni = this;
    while ((licznik < q)&&(ostatni->next != NULL))
    {
        ostatni = ostatni -> next;
        licznik++;
    }
    cout << ostatni->imieAktora<<" "<<ostatni->nazwiskoAktora<<" "<< ostatni->imiePostaci << " " << ostatni->nazwiskoPostaci << " " << ostatni->pierwszyOdcinek << " " << ostatni->ostatniOdcinek << endl;
    return ostatni;
}

ostream& book::operator<<(ostream& os, book& a)
{
    os << a.imieAktora << " " << a.nazwiskoAktora << " " << a.imiePostaci << " " << a.nazwiskoPostaci << " " << a.pierwszyOdcinek << " " << a.ostatniOdcinek << endl;
    return os;
}
