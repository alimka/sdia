#ifndef BOOK_H
#define BOOK_H

#include <string>

using namespace std;

class Book
{
public:
    string imieAktora, nazwiskoAktora, imiePostaci, nazwiskoPostaci;
    int pierwszyOdcinek, ostatniOdcinek;

    Book *next;
    Book *prev;

    Book();
    Book (string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek);

    void dodaj(string imieAktora, string nazwiskoAktora, string imiePostaci, string nazwiskoPostaci, int pierwszyOdcinek, int ostatniOdcinek);
    void drukuj();
    void drukuj(int i);

};

#endif // BOOK_H
